import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'package:styled_widget/styled_widget.dart';

import '../../Constant.dart';

class RouteWithNavigator extends StatefulWidget {
  const RouteWithNavigator({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _RouteWithNavigatorState();
}

class _RouteWithNavigatorState extends State<RouteWithNavigator> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [Container().backgroundColor(Colors.black)],
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container()
                .backgroundImage(DecorationImage(
                    image: CachedNetworkImageProvider(netflixIconUrl),
                    fit: BoxFit.contain))
                .height(50)
                .width(70)
                .opacity(0.9),
            const Icon(FontAwesomeIcons.chromecast).iconSize(26).opacity(0.7),
            const Icon(FontAwesomeIcons.chromecast).iconSize(26).opacity(0.7),
            const Icon(FontAwesomeIcons.chromecast).iconSize(26).opacity(0.7),
          ],
        ),
      ],
    );
  }
}
